<?php
$servername = "db";
$username = "webdinamica";
$password = "abcd1234@";
$dbname = "portfolio";

$conn = new mysqli($servername, $username, $password, $dbname);
$sql = " SELECT * FROM proyectos";
$result = $conn->query($sql);
$conn->close();
?>

<html data-bs-theme="light" lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Title</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/aos.min.css">
    <link rel="stylesheet" href="assets/css/Contact-Form-by-Moorcam.css">
</head>

<body class="bg-dark">
    <header>
        <nav class="navbar bg-black">
            <div class="container-fluid"><a class="navbar-brand text-light">Sergio Matossi</a>
            </div>
        </nav>
    </header>
    <main>
        <div class="text-center p-5 bg-image" data-aos="fade-up"
            style="background-image: url('https://wallpapers.com/images/featured/fondos-de-gradiente-morado-rmfznb3wauiky4u8.jpg');height: 400px;padding-bottom: 0px;">
            <div class="mask">
                <div class="d-flex justify-content-center align-items-center h-100">
                    <div class="text-white"><br>
                        <h1 class="mb-3">Sergio Matossi</h1>
                        <h4 class="mb-3">Bienvenido a mi pagina personal</h4><br>
                    </div>
                </div>
            </div>
        </div>
        <div class="accordion accordion-flush w-100 p-3" role="tablist" data-aos="zoom-in" id="accordionFlushExample"
            style="padding-left: 0px;">
            <div class="accordion-item">
                <h2 class="accordion-header" role="tab"><button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false"
                        aria-controls="flush-collapseOne"> Sobre mi </button></h2>
                <div class="accordion-collapse collapse show item-1" role="tabpanel"
                    data-bs-parent="#accordionFlushExample" id="flush-collapseOne">
                    <div class="accordion-body"><span>Soy Sergio Matossi, un chico de 19 años residente en españa que
                            desde siempre le han interesado los ordenadores</span></div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" role="tab"><button class="accordion-button collapsed collapsed"
                        type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo"
                        aria-expanded="false" aria-controls="flush-collapseTwo"> Donde he estudiado </button></h2>
                <div class="accordion-collapse collapse item-2" role="tabpanel" data-bs-parent="#accordionFlushExample"
                    id="flush-collapseTwo">
                    <div class="accordion-body"><span>Comenze mis estudios post-obligatorios en Salesianos Pamplona
                            donde estudie Sistemas microinformaticos y redes durante 2 años y tras terminar eso fui a
                            estudiar a Cuatrovientos para cursar Administracion de sistemas informaticos en red</span>
                    </div>
                </div>
            </div>
            <div class="accordion-item">
                <h2 class="accordion-header" role="tab"><button class="accordion-button collapsed collapsed"
                        type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree"
                        aria-expanded="false" aria-controls="flush-collapseThree"> Intereses personales </button></h2>
                <div class="accordion-collapse collapse item-3" role="tabpanel" data-bs-parent="#accordionFlushExample"
                    id="flush-collapseThree">
                    <div class="accordion-body">
                        <ul>
                            <li>Informatica</li>
                            <li>Videojuegos</li>
                            <li>Musica</li>
                            <li>Animacion 3D </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="mask">
            <div class="d-flex justify-content-center align-items-center h-100" style="margin-bottom: 23px;">
                <div class="text-white"><br>
                    <h1 class="mb-3">Proyectos</h1><br>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
            <?php
                    while ($rows = $result->fetch_assoc()) {
                        ?>
                <div class="col-md-6" data-aos="zoom-in-right" style="margin-bottom: 48px;">
                    <div class="card">
                    <img src="proyectos\<?php echo $rows['image']; ?>" height="116" width="304" class="card-img-top">
                    <div class="card-body">
                    <h5 class="card-title"><?php echo $rows['title']; ?></h5>
                    <p class="card-text"><?php echo $rows['description']; ?></p>
                    </div>
                </div>
                <?php
                    }
                    ?>
            </div>
        </div>
        <div class="bg-info">
            <br>
            <br>
            <div class="mx-auto p-2" style="width: 600px;">
                <section class="shadow contact-clean" data-aos="zoom-in">
                    <form class="bg-light border rounded border-secondary shadow-lg needs-validation" novalidate>
                        <h2 class="text-center">Contactame</h2>
                        <div class="form-group mb-3 p-2">
                            <input class="form-control" type="text" name="name" placeholder="Nombre" required>
                            <div class="invalid-feedback">Por favor, ingresa tu nombre.</div>
                        </div>
                        <div class="form-group mb-3 p-2">
                            <input class="form-control" type="text" name="phone" placeholder="Telefono" inputmode="tel"
                                required pattern="\d+">
                            <div class="invalid-feedback">Por favor, ingresa un número de teléfono válido (solo
                                números).
                            </div>
                        </div>
                        <div class="form-group mb-3 p-2">
                            <input class="form-control" type="email" name="email" placeholder="Email" required>
                            <div class="invalid-feedback">Por favor, ingresa un correo electrónico válido.</div>
                        </div>
                        <div class="form-group mb-3 p-2">
                            <textarea class="form-control" name="message" placeholder="Mensaje" rows="14"
                                required></textarea>
                            <div class="invalid-feedback">Por favor, escribe un mensaje.</div>
                        </div>
                        <div class="form-group mb-3 p-2">
                            <button class="btn btn-primary" type="submit">Enviar</button>
                        </div>
                    </form>
                </section><br><br>
            </div>
        </div>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    </main>
    <footer class="text-center text-lg-start bg-body-tertiary">
        <div class="text-center p-3"><span> Sergio Matossi 2024 2ºASIR </span></div>
    </footer>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/aos.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>